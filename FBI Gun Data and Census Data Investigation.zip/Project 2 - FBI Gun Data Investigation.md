# Project: Data Invetigation - FBI Gun Dataset

# Table of Content

1. [Introduction](#introduction)
2. [Data Wrangling](#wrangling)
3. [Data Cleaning](#cleaning)
4. [Exploratory Data Analysis](#analysis)
5. [Conclusion](#conclusion)

<a id='introduction'></a>
# Introduction

        In the second Project of Udacity Program we are working on a dataset that comes from *FBI's National Instant Criminal Background Check System*. The work will focus on investing a Gun Data through two datasets: **Gun Data**, where we can see information on gun purchases regarding different state, type of purchase and periodic firearm checks,  and **US Census Data**, where we are given data regarding the population statistics and categories for each state. 
        This data was originally created to provide security for gun shops by having a background check on a potential buyers regarding his/her license to purchase a gun or explosive, and the if the buyer has any sort of criminal record. Census data is given to see the demogprahic of United States of America
    
**Questions to Answer:**

1. What is the overall trend of gun purchases? 
2. How many permit rechecks have their been?
3. What was the state with the lowest percentage for Asians Alone?
4. What was the state with the lowest percentage for Asians Alone?
5. How many guns were registered in the year 2017, January? What is that number compared to the data 10 years ago? 
6. What is the most popular gun sale in the whole data?


```python
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
%matplotlib inline
```

<a id='wrangling'></a>
# Data Wrangling 


```python
# Load csv and excel data 

df_gun = pd.read_excel('gun_data.xlsx')

df_census = pd.read_csv('US_census_data.csv')
```


```python
df_gun
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>month</th>
      <th>state</th>
      <th>permit</th>
      <th>permit_recheck</th>
      <th>handgun</th>
      <th>long_gun</th>
      <th>other</th>
      <th>multiple</th>
      <th>admin</th>
      <th>prepawn_handgun</th>
      <th>...</th>
      <th>returned_other</th>
      <th>rentals_handgun</th>
      <th>rentals_long_gun</th>
      <th>private_sale_handgun</th>
      <th>private_sale_long_gun</th>
      <th>private_sale_other</th>
      <th>return_to_seller_handgun</th>
      <th>return_to_seller_long_gun</th>
      <th>return_to_seller_other</th>
      <th>totals</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <td>0</td>
      <td>2017-09</td>
      <td>Alabama</td>
      <td>16717.0</td>
      <td>0.0</td>
      <td>5734.0</td>
      <td>6320.0</td>
      <td>221.0</td>
      <td>317</td>
      <td>0.0</td>
      <td>15.0</td>
      <td>...</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>9.0</td>
      <td>16.0</td>
      <td>3.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>3.0</td>
      <td>32019</td>
    </tr>
    <tr>
      <td>1</td>
      <td>2017-09</td>
      <td>Alaska</td>
      <td>209.0</td>
      <td>2.0</td>
      <td>2320.0</td>
      <td>2930.0</td>
      <td>219.0</td>
      <td>160</td>
      <td>0.0</td>
      <td>5.0</td>
      <td>...</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>17.0</td>
      <td>24.0</td>
      <td>1.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>6303</td>
    </tr>
    <tr>
      <td>2</td>
      <td>2017-09</td>
      <td>Arizona</td>
      <td>5069.0</td>
      <td>382.0</td>
      <td>11063.0</td>
      <td>7946.0</td>
      <td>920.0</td>
      <td>631</td>
      <td>0.0</td>
      <td>13.0</td>
      <td>...</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>38.0</td>
      <td>12.0</td>
      <td>2.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>28394</td>
    </tr>
    <tr>
      <td>3</td>
      <td>2017-09</td>
      <td>Arkansas</td>
      <td>2935.0</td>
      <td>632.0</td>
      <td>4347.0</td>
      <td>6063.0</td>
      <td>165.0</td>
      <td>366</td>
      <td>51.0</td>
      <td>12.0</td>
      <td>...</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>13.0</td>
      <td>23.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>2.0</td>
      <td>1.0</td>
      <td>17747</td>
    </tr>
    <tr>
      <td>4</td>
      <td>2017-09</td>
      <td>California</td>
      <td>57839.0</td>
      <td>0.0</td>
      <td>37165.0</td>
      <td>24581.0</td>
      <td>2984.0</td>
      <td>0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>...</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>123506</td>
    </tr>
    <tr>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
    </tr>
    <tr>
      <td>12480</td>
      <td>1998-11</td>
      <td>Virginia</td>
      <td>0.0</td>
      <td>NaN</td>
      <td>14.0</td>
      <td>2.0</td>
      <td>NaN</td>
      <td>8</td>
      <td>0.0</td>
      <td>NaN</td>
      <td>...</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>24</td>
    </tr>
    <tr>
      <td>12481</td>
      <td>1998-11</td>
      <td>Washington</td>
      <td>1.0</td>
      <td>NaN</td>
      <td>65.0</td>
      <td>286.0</td>
      <td>NaN</td>
      <td>8</td>
      <td>1.0</td>
      <td>NaN</td>
      <td>...</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>361</td>
    </tr>
    <tr>
      <td>12482</td>
      <td>1998-11</td>
      <td>West Virginia</td>
      <td>3.0</td>
      <td>NaN</td>
      <td>149.0</td>
      <td>251.0</td>
      <td>NaN</td>
      <td>5</td>
      <td>0.0</td>
      <td>NaN</td>
      <td>...</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>408</td>
    </tr>
    <tr>
      <td>12483</td>
      <td>1998-11</td>
      <td>Wisconsin</td>
      <td>0.0</td>
      <td>NaN</td>
      <td>25.0</td>
      <td>214.0</td>
      <td>NaN</td>
      <td>2</td>
      <td>0.0</td>
      <td>NaN</td>
      <td>...</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>241</td>
    </tr>
    <tr>
      <td>12484</td>
      <td>1998-11</td>
      <td>Wyoming</td>
      <td>8.0</td>
      <td>NaN</td>
      <td>45.0</td>
      <td>49.0</td>
      <td>NaN</td>
      <td>5</td>
      <td>0.0</td>
      <td>NaN</td>
      <td>...</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>107</td>
    </tr>
  </tbody>
</table>
<p>12485 rows × 27 columns</p>
</div>




```python
df_gun.head() 
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>month</th>
      <th>state</th>
      <th>permit</th>
      <th>permit_recheck</th>
      <th>handgun</th>
      <th>long_gun</th>
      <th>other</th>
      <th>multiple</th>
      <th>admin</th>
      <th>prepawn_handgun</th>
      <th>...</th>
      <th>returned_other</th>
      <th>rentals_handgun</th>
      <th>rentals_long_gun</th>
      <th>private_sale_handgun</th>
      <th>private_sale_long_gun</th>
      <th>private_sale_other</th>
      <th>return_to_seller_handgun</th>
      <th>return_to_seller_long_gun</th>
      <th>return_to_seller_other</th>
      <th>totals</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <td>0</td>
      <td>2017-09</td>
      <td>Alabama</td>
      <td>16717.0</td>
      <td>0.0</td>
      <td>5734.0</td>
      <td>6320.0</td>
      <td>221.0</td>
      <td>317</td>
      <td>0.0</td>
      <td>15.0</td>
      <td>...</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>9.0</td>
      <td>16.0</td>
      <td>3.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>3.0</td>
      <td>32019</td>
    </tr>
    <tr>
      <td>1</td>
      <td>2017-09</td>
      <td>Alaska</td>
      <td>209.0</td>
      <td>2.0</td>
      <td>2320.0</td>
      <td>2930.0</td>
      <td>219.0</td>
      <td>160</td>
      <td>0.0</td>
      <td>5.0</td>
      <td>...</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>17.0</td>
      <td>24.0</td>
      <td>1.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>6303</td>
    </tr>
    <tr>
      <td>2</td>
      <td>2017-09</td>
      <td>Arizona</td>
      <td>5069.0</td>
      <td>382.0</td>
      <td>11063.0</td>
      <td>7946.0</td>
      <td>920.0</td>
      <td>631</td>
      <td>0.0</td>
      <td>13.0</td>
      <td>...</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>38.0</td>
      <td>12.0</td>
      <td>2.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>28394</td>
    </tr>
    <tr>
      <td>3</td>
      <td>2017-09</td>
      <td>Arkansas</td>
      <td>2935.0</td>
      <td>632.0</td>
      <td>4347.0</td>
      <td>6063.0</td>
      <td>165.0</td>
      <td>366</td>
      <td>51.0</td>
      <td>12.0</td>
      <td>...</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>13.0</td>
      <td>23.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>2.0</td>
      <td>1.0</td>
      <td>17747</td>
    </tr>
    <tr>
      <td>4</td>
      <td>2017-09</td>
      <td>California</td>
      <td>57839.0</td>
      <td>0.0</td>
      <td>37165.0</td>
      <td>24581.0</td>
      <td>2984.0</td>
      <td>0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>...</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>123506</td>
    </tr>
  </tbody>
</table>
<p>5 rows × 27 columns</p>
</div>




```python
df_gun.describe()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>permit</th>
      <th>permit_recheck</th>
      <th>handgun</th>
      <th>long_gun</th>
      <th>other</th>
      <th>multiple</th>
      <th>admin</th>
      <th>prepawn_handgun</th>
      <th>prepawn_long_gun</th>
      <th>prepawn_other</th>
      <th>...</th>
      <th>returned_other</th>
      <th>rentals_handgun</th>
      <th>rentals_long_gun</th>
      <th>private_sale_handgun</th>
      <th>private_sale_long_gun</th>
      <th>private_sale_other</th>
      <th>return_to_seller_handgun</th>
      <th>return_to_seller_long_gun</th>
      <th>return_to_seller_other</th>
      <th>totals</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <td>count</td>
      <td>12461.000000</td>
      <td>1100.000000</td>
      <td>12465.000000</td>
      <td>12466.000000</td>
      <td>5500.000000</td>
      <td>12485.000000</td>
      <td>12462.000000</td>
      <td>10542.000000</td>
      <td>10540.000000</td>
      <td>5115.000000</td>
      <td>...</td>
      <td>1815.000000</td>
      <td>990.000000</td>
      <td>825.000000</td>
      <td>2750.000000</td>
      <td>2750.000000</td>
      <td>2750.000000</td>
      <td>2475.000000</td>
      <td>2750.000000</td>
      <td>2255.000000</td>
      <td>12485.000000</td>
    </tr>
    <tr>
      <td>mean</td>
      <td>6413.629404</td>
      <td>1165.956364</td>
      <td>5940.881107</td>
      <td>7810.847585</td>
      <td>360.471636</td>
      <td>268.603364</td>
      <td>58.898090</td>
      <td>4.828021</td>
      <td>7.834156</td>
      <td>0.165591</td>
      <td>...</td>
      <td>1.027548</td>
      <td>0.076768</td>
      <td>0.087273</td>
      <td>14.936000</td>
      <td>11.602909</td>
      <td>1.030182</td>
      <td>0.402020</td>
      <td>0.441818</td>
      <td>0.105987</td>
      <td>21595.725911</td>
    </tr>
    <tr>
      <td>std</td>
      <td>23752.338269</td>
      <td>9224.200609</td>
      <td>8618.584060</td>
      <td>9309.846140</td>
      <td>1349.478273</td>
      <td>783.185073</td>
      <td>604.814818</td>
      <td>10.907756</td>
      <td>16.468028</td>
      <td>1.057105</td>
      <td>...</td>
      <td>4.386296</td>
      <td>0.634503</td>
      <td>0.671649</td>
      <td>71.216021</td>
      <td>54.253090</td>
      <td>4.467843</td>
      <td>1.446568</td>
      <td>1.528223</td>
      <td>0.427363</td>
      <td>32591.418387</td>
    </tr>
    <tr>
      <td>min</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>...</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
    </tr>
    <tr>
      <td>25%</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>865.000000</td>
      <td>2078.250000</td>
      <td>17.000000</td>
      <td>15.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>...</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>4638.000000</td>
    </tr>
    <tr>
      <td>50%</td>
      <td>518.000000</td>
      <td>0.000000</td>
      <td>3059.000000</td>
      <td>5122.000000</td>
      <td>121.000000</td>
      <td>125.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>1.000000</td>
      <td>0.000000</td>
      <td>...</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>12399.000000</td>
    </tr>
    <tr>
      <td>75%</td>
      <td>4272.000000</td>
      <td>0.000000</td>
      <td>7280.000000</td>
      <td>10380.750000</td>
      <td>354.000000</td>
      <td>301.000000</td>
      <td>0.000000</td>
      <td>5.000000</td>
      <td>8.000000</td>
      <td>0.000000</td>
      <td>...</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>2.000000</td>
      <td>4.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>25453.000000</td>
    </tr>
    <tr>
      <td>max</td>
      <td>522188.000000</td>
      <td>116681.000000</td>
      <td>107224.000000</td>
      <td>108058.000000</td>
      <td>77929.000000</td>
      <td>38907.000000</td>
      <td>28083.000000</td>
      <td>164.000000</td>
      <td>269.000000</td>
      <td>49.000000</td>
      <td>...</td>
      <td>64.000000</td>
      <td>12.000000</td>
      <td>12.000000</td>
      <td>1017.000000</td>
      <td>777.000000</td>
      <td>71.000000</td>
      <td>28.000000</td>
      <td>17.000000</td>
      <td>4.000000</td>
      <td>541978.000000</td>
    </tr>
  </tbody>
</table>
<p>8 rows × 25 columns</p>
</div>




```python
df_census.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Fact</th>
      <th>Fact Note</th>
      <th>Alabama</th>
      <th>Alaska</th>
      <th>Arizona</th>
      <th>Arkansas</th>
      <th>California</th>
      <th>Colorado</th>
      <th>Connecticut</th>
      <th>Delaware</th>
      <th>...</th>
      <th>South Dakota</th>
      <th>Tennessee</th>
      <th>Texas</th>
      <th>Utah</th>
      <th>Vermont</th>
      <th>Virginia</th>
      <th>Washington</th>
      <th>West Virginia</th>
      <th>Wisconsin</th>
      <th>Wyoming</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <td>0</td>
      <td>Population estimates, July 1, 2016,  (V2016)</td>
      <td>NaN</td>
      <td>4,863,300</td>
      <td>741,894</td>
      <td>6,931,071</td>
      <td>2,988,248</td>
      <td>39,250,017</td>
      <td>5,540,545</td>
      <td>3,576,452</td>
      <td>952,065</td>
      <td>...</td>
      <td>865454.000</td>
      <td>6651194.000</td>
      <td>27,862,596</td>
      <td>3,051,217</td>
      <td>624,594</td>
      <td>8,411,808</td>
      <td>7,288,000</td>
      <td>1,831,102</td>
      <td>5,778,708</td>
      <td>585,501</td>
    </tr>
    <tr>
      <td>1</td>
      <td>Population estimates base, April 1, 2010,  (V2...</td>
      <td>NaN</td>
      <td>4,780,131</td>
      <td>710,249</td>
      <td>6,392,301</td>
      <td>2,916,025</td>
      <td>37,254,522</td>
      <td>5,029,324</td>
      <td>3,574,114</td>
      <td>897,936</td>
      <td>...</td>
      <td>814195.000</td>
      <td>6346298.000</td>
      <td>25,146,100</td>
      <td>2,763,888</td>
      <td>625,741</td>
      <td>8,001,041</td>
      <td>6,724,545</td>
      <td>1,853,011</td>
      <td>5,687,289</td>
      <td>563,767</td>
    </tr>
    <tr>
      <td>2</td>
      <td>Population, percent change - April 1, 2010 (es...</td>
      <td>NaN</td>
      <td>1.70%</td>
      <td>4.50%</td>
      <td>8.40%</td>
      <td>2.50%</td>
      <td>5.40%</td>
      <td>10.20%</td>
      <td>0.10%</td>
      <td>6.00%</td>
      <td>...</td>
      <td>0.063</td>
      <td>0.048</td>
      <td>10.80%</td>
      <td>10.40%</td>
      <td>-0.20%</td>
      <td>5.10%</td>
      <td>8.40%</td>
      <td>-1.20%</td>
      <td>1.60%</td>
      <td>3.90%</td>
    </tr>
    <tr>
      <td>3</td>
      <td>Population, Census, April 1, 2010</td>
      <td>NaN</td>
      <td>4,779,736</td>
      <td>710,231</td>
      <td>6,392,017</td>
      <td>2,915,918</td>
      <td>37,253,956</td>
      <td>5,029,196</td>
      <td>3,574,097</td>
      <td>897,934</td>
      <td>...</td>
      <td>814180.000</td>
      <td>6346105.000</td>
      <td>25,145,561</td>
      <td>2,763,885</td>
      <td>625,741</td>
      <td>8,001,024</td>
      <td>6,724,540</td>
      <td>1,852,994</td>
      <td>5,686,986</td>
      <td>563,626</td>
    </tr>
    <tr>
      <td>4</td>
      <td>Persons under 5 years, percent, July 1, 2016, ...</td>
      <td>NaN</td>
      <td>6.00%</td>
      <td>7.30%</td>
      <td>6.30%</td>
      <td>6.40%</td>
      <td>6.30%</td>
      <td>6.10%</td>
      <td>5.20%</td>
      <td>5.80%</td>
      <td>...</td>
      <td>0.071</td>
      <td>0.061</td>
      <td>7.20%</td>
      <td>8.30%</td>
      <td>4.90%</td>
      <td>6.10%</td>
      <td>6.20%</td>
      <td>5.50%</td>
      <td>5.80%</td>
      <td>6.50%</td>
    </tr>
  </tbody>
</table>
<p>5 rows × 52 columns</p>
</div>




```python
df_census.tail()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Fact</th>
      <th>Fact Note</th>
      <th>Alabama</th>
      <th>Alaska</th>
      <th>Arizona</th>
      <th>Arkansas</th>
      <th>California</th>
      <th>Colorado</th>
      <th>Connecticut</th>
      <th>Delaware</th>
      <th>...</th>
      <th>South Dakota</th>
      <th>Tennessee</th>
      <th>Texas</th>
      <th>Utah</th>
      <th>Vermont</th>
      <th>Virginia</th>
      <th>Washington</th>
      <th>West Virginia</th>
      <th>Wisconsin</th>
      <th>Wyoming</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <td>59</td>
      <td>Nonminority-owned firms, 2012</td>
      <td>NaN</td>
      <td>272,651</td>
      <td>51,147</td>
      <td>344,981</td>
      <td>189,029</td>
      <td>1,819,107</td>
      <td>442,365</td>
      <td>259,614</td>
      <td>54,782</td>
      <td>...</td>
      <td>74228.0</td>
      <td>434025.0</td>
      <td>1,224,845</td>
      <td>218,826</td>
      <td>70,491</td>
      <td>450,109</td>
      <td>426,697</td>
      <td>104,785</td>
      <td>379,934</td>
      <td>55,397</td>
    </tr>
    <tr>
      <td>60</td>
      <td>Veteran-owned firms, 2012</td>
      <td>NaN</td>
      <td>41,943</td>
      <td>7,953</td>
      <td>46,780</td>
      <td>25,915</td>
      <td>252,377</td>
      <td>51,722</td>
      <td>31,056</td>
      <td>7,206</td>
      <td>...</td>
      <td>8604.0</td>
      <td>59379.0</td>
      <td>213,590</td>
      <td>18,754</td>
      <td>8,237</td>
      <td>76,434</td>
      <td>49,331</td>
      <td>12,912</td>
      <td>39,830</td>
      <td>6,470</td>
    </tr>
    <tr>
      <td>61</td>
      <td>Nonveteran-owned firms, 2012</td>
      <td>NaN</td>
      <td>316,984</td>
      <td>56,091</td>
      <td>427,582</td>
      <td>192,988</td>
      <td>3,176,341</td>
      <td>469,524</td>
      <td>281,182</td>
      <td>60,318</td>
      <td>...</td>
      <td>66219.0</td>
      <td>469392.0</td>
      <td>2,057,218</td>
      <td>219,807</td>
      <td>63,317</td>
      <td>548,439</td>
      <td>461,401</td>
      <td>94,960</td>
      <td>370,755</td>
      <td>51,353</td>
    </tr>
    <tr>
      <td>62</td>
      <td>Population per square mile, 2010</td>
      <td>NaN</td>
      <td>94.4</td>
      <td>1.2</td>
      <td>56.3</td>
      <td>56</td>
      <td>239.1</td>
      <td>48.5</td>
      <td>738.1</td>
      <td>460.8</td>
      <td>...</td>
      <td>10.7</td>
      <td>153.9</td>
      <td>96.3</td>
      <td>33.6</td>
      <td>67.9</td>
      <td>202.6</td>
      <td>101.2</td>
      <td>77.1</td>
      <td>105</td>
      <td>5.8</td>
    </tr>
    <tr>
      <td>63</td>
      <td>Land area in square miles, 2010</td>
      <td>NaN</td>
      <td>50,645.33</td>
      <td>570,640.95</td>
      <td>113,594.08</td>
      <td>52,035.48</td>
      <td>155,779.22</td>
      <td>103,641.89</td>
      <td>4,842.36</td>
      <td>1,948.54</td>
      <td>...</td>
      <td>75811.0</td>
      <td>41234.9</td>
      <td>261,231.71</td>
      <td>82,169.62</td>
      <td>9,216.66</td>
      <td>39,490.09</td>
      <td>66,455.52</td>
      <td>24,038.21</td>
      <td>54,157.80</td>
      <td>97,093.14</td>
    </tr>
  </tbody>
</table>
<p>5 rows × 52 columns</p>
</div>




```python
df_gun.hist(figsize=(20,20));
```


![png](output_11_0.png)



```python
df_gun.shape, df_census.shape
```




    ((12485, 27), (64, 52))



<a id='cleaning'></a>
# Cleaning Dataset
**We have to remove any possible duplicates, give proper types to the data and see if the gun data and census data correspond together with quantity and quality.**


```python
#Since both data sets were read perfectly it is time to clean the data sets in order to properly carry out an analysis.
df_gun.dtypes
```




    month                         object
    state                         object
    permit                       float64
    permit_recheck               float64
    handgun                      float64
    long_gun                     float64
    other                        float64
    multiple                       int64
    admin                        float64
    prepawn_handgun              float64
    prepawn_long_gun             float64
    prepawn_other                float64
    redemption_handgun           float64
    redemption_long_gun          float64
    redemption_other             float64
    returned_handgun             float64
    returned_long_gun            float64
    returned_other               float64
    rentals_handgun              float64
    rentals_long_gun             float64
    private_sale_handgun         float64
    private_sale_long_gun        float64
    private_sale_other           float64
    return_to_seller_handgun     float64
    return_to_seller_long_gun    float64
    return_to_seller_other       float64
    totals                         int64
    dtype: object




```python
type(df_gun['month'][0])
type(df_gun['state'][0])
```




    str



**Eventhough month and state are illustrated as an object type, when we run an individual type code we can see it being illustrated as a string.** 


```python
df_gun.count()
```




    month                        12485
    state                        12485
    permit                       12461
    permit_recheck                1100
    handgun                      12465
    long_gun                     12466
    other                         5500
    multiple                     12485
    admin                        12462
    prepawn_handgun              10542
    prepawn_long_gun             10540
    prepawn_other                 5115
    redemption_handgun           10545
    redemption_long_gun          10544
    redemption_other              5115
    returned_handgun              2200
    returned_long_gun             2145
    returned_other                1815
    rentals_handgun                990
    rentals_long_gun               825
    private_sale_handgun          2750
    private_sale_long_gun         2750
    private_sale_other            2750
    return_to_seller_handgun      2475
    return_to_seller_long_gun     2750
    return_to_seller_other        2255
    totals                       12485
    dtype: int64



**We can see that 'month' and 'state' has the same count as 'totals' unlike all the other numbers. This suggests that some of the values are Null-Values or have not been mentioned at all.**


```python
sum(df_census.duplicated())
```




    0




```python
sum(df_gun.duplicated())
```




    0




```python
df_census.isnull().sum().any()
```




    True




```python
df_gun.isnull().sum().any()
```




    True




```python
df_census.info()
```

    <class 'pandas.core.frame.DataFrame'>
    RangeIndex: 64 entries, 0 to 63
    Data columns (total 52 columns):
    Fact              64 non-null object
    Fact Note         16 non-null object
    Alabama           64 non-null object
    Alaska            64 non-null object
    Arizona           64 non-null object
    Arkansas          64 non-null object
    California        64 non-null object
    Colorado          64 non-null object
    Connecticut       64 non-null object
    Delaware          64 non-null object
    Florida           64 non-null object
    Georgia           64 non-null object
    Hawaii            64 non-null object
    Idaho             64 non-null object
    Illinois          64 non-null object
    Indiana           64 non-null object
    Iowa              64 non-null object
    Kansas            64 non-null object
    Kentucky          64 non-null object
    Louisiana         64 non-null object
    Maine             64 non-null object
    Maryland          64 non-null object
    Massachusetts     64 non-null object
    Michigan          64 non-null object
    Minnesota         64 non-null object
    Mississippi       64 non-null object
    Missouri          64 non-null object
    Montana           64 non-null object
    Nebraska          64 non-null object
    Nevada            64 non-null object
    New Hampshire     64 non-null object
    New Jersey        64 non-null object
    New Mexico        64 non-null float64
    New York          64 non-null float64
    North Carolina    64 non-null float64
    North Dakota      64 non-null float64
    Ohio              64 non-null float64
    Oklahoma          64 non-null float64
    Oregon            64 non-null float64
    Pennsylvania      64 non-null float64
    Rhode Island      64 non-null float64
    South Carolina    64 non-null float64
    South Dakota      64 non-null float64
    Tennessee         64 non-null float64
    Texas             64 non-null object
    Utah              64 non-null object
    Vermont           64 non-null object
    Virginia          64 non-null object
    Washington        64 non-null object
    West Virginia     64 non-null object
    Wisconsin         64 non-null object
    Wyoming           64 non-null object
    dtypes: float64(12), object(40)
    memory usage: 26.1+ KB
    


```python
df_gun.info()
```

    <class 'pandas.core.frame.DataFrame'>
    RangeIndex: 12485 entries, 0 to 12484
    Data columns (total 27 columns):
    month                        12485 non-null object
    state                        12485 non-null object
    permit                       12461 non-null float64
    permit_recheck               1100 non-null float64
    handgun                      12465 non-null float64
    long_gun                     12466 non-null float64
    other                        5500 non-null float64
    multiple                     12485 non-null int64
    admin                        12462 non-null float64
    prepawn_handgun              10542 non-null float64
    prepawn_long_gun             10540 non-null float64
    prepawn_other                5115 non-null float64
    redemption_handgun           10545 non-null float64
    redemption_long_gun          10544 non-null float64
    redemption_other             5115 non-null float64
    returned_handgun             2200 non-null float64
    returned_long_gun            2145 non-null float64
    returned_other               1815 non-null float64
    rentals_handgun              990 non-null float64
    rentals_long_gun             825 non-null float64
    private_sale_handgun         2750 non-null float64
    private_sale_long_gun        2750 non-null float64
    private_sale_other           2750 non-null float64
    return_to_seller_handgun     2475 non-null float64
    return_to_seller_long_gun    2750 non-null float64
    return_to_seller_other       2255 non-null float64
    totals                       12485 non-null int64
    dtypes: float64(23), int64(2), object(2)
    memory usage: 2.6+ MB
    


```python
df_census.dtypes
```




    Fact               object
    Fact Note          object
    Alabama            object
    Alaska             object
    Arizona            object
    Arkansas           object
    California         object
    Colorado           object
    Connecticut        object
    Delaware           object
    Florida            object
    Georgia            object
    Hawaii             object
    Idaho              object
    Illinois           object
    Indiana            object
    Iowa               object
    Kansas             object
    Kentucky           object
    Louisiana          object
    Maine              object
    Maryland           object
    Massachusetts      object
    Michigan           object
    Minnesota          object
    Mississippi        object
    Missouri           object
    Montana            object
    Nebraska           object
    Nevada             object
    New Hampshire      object
    New Jersey         object
    New Mexico        float64
    New York          float64
    North Carolina    float64
    North Dakota      float64
    Ohio              float64
    Oklahoma          float64
    Oregon            float64
    Pennsylvania      float64
    Rhode Island      float64
    South Carolina    float64
    South Dakota      float64
    Tennessee         float64
    Texas              object
    Utah               object
    Vermont            object
    Virginia           object
    Washington         object
    West Virginia      object
    Wisconsin          object
    Wyoming            object
    dtype: object




```python
#Now we are only selecting the columns that we will be needing to do an analysis.

df_gun1 = df_gun[['month','state','totals']]
df_gun1
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>month</th>
      <th>state</th>
      <th>totals</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <td>0</td>
      <td>2017-09</td>
      <td>Alabama</td>
      <td>32019</td>
    </tr>
    <tr>
      <td>1</td>
      <td>2017-09</td>
      <td>Alaska</td>
      <td>6303</td>
    </tr>
    <tr>
      <td>2</td>
      <td>2017-09</td>
      <td>Arizona</td>
      <td>28394</td>
    </tr>
    <tr>
      <td>3</td>
      <td>2017-09</td>
      <td>Arkansas</td>
      <td>17747</td>
    </tr>
    <tr>
      <td>4</td>
      <td>2017-09</td>
      <td>California</td>
      <td>123506</td>
    </tr>
    <tr>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
    </tr>
    <tr>
      <td>12480</td>
      <td>1998-11</td>
      <td>Virginia</td>
      <td>24</td>
    </tr>
    <tr>
      <td>12481</td>
      <td>1998-11</td>
      <td>Washington</td>
      <td>361</td>
    </tr>
    <tr>
      <td>12482</td>
      <td>1998-11</td>
      <td>West Virginia</td>
      <td>408</td>
    </tr>
    <tr>
      <td>12483</td>
      <td>1998-11</td>
      <td>Wisconsin</td>
      <td>241</td>
    </tr>
    <tr>
      <td>12484</td>
      <td>1998-11</td>
      <td>Wyoming</td>
      <td>107</td>
    </tr>
  </tbody>
</table>
<p>12485 rows × 3 columns</p>
</div>



**Since all the data inside census data is listed as object type, we will need to change them into numeric later**


```python
# Make sure that the census data does not start the index with the 'fact' or 'fact note'. 
index_census_state = df_census.iloc[0].index
index_census_state
```




    Index(['Fact', 'Fact Note', 'Alabama', 'Alaska', 'Arizona', 'Arkansas',
           'California', 'Colorado', 'Connecticut', 'Delaware', 'Florida',
           'Georgia', 'Hawaii', 'Idaho', 'Illinois', 'Indiana', 'Iowa', 'Kansas',
           'Kentucky', 'Louisiana', 'Maine', 'Maryland', 'Massachusetts',
           'Michigan', 'Minnesota', 'Mississippi', 'Missouri', 'Montana',
           'Nebraska', 'Nevada', 'New Hampshire', 'New Jersey', 'New Mexico',
           'New York', 'North Carolina', 'North Dakota', 'Ohio', 'Oklahoma',
           'Oregon', 'Pennsylvania', 'Rhode Island', 'South Carolina',
           'South Dakota', 'Tennessee', 'Texas', 'Utah', 'Vermont', 'Virginia',
           'Washington', 'West Virginia', 'Wisconsin', 'Wyoming'],
          dtype='object')




```python
index_census_state = index_census_state[2:]
index_census_state
```




    Index(['Alabama', 'Alaska', 'Arizona', 'Arkansas', 'California', 'Colorado',
           'Connecticut', 'Delaware', 'Florida', 'Georgia', 'Hawaii', 'Idaho',
           'Illinois', 'Indiana', 'Iowa', 'Kansas', 'Kentucky', 'Louisiana',
           'Maine', 'Maryland', 'Massachusetts', 'Michigan', 'Minnesota',
           'Mississippi', 'Missouri', 'Montana', 'Nebraska', 'Nevada',
           'New Hampshire', 'New Jersey', 'New Mexico', 'New York',
           'North Carolina', 'North Dakota', 'Ohio', 'Oklahoma', 'Oregon',
           'Pennsylvania', 'Rhode Island', 'South Carolina', 'South Dakota',
           'Tennessee', 'Texas', 'Utah', 'Vermont', 'Virginia', 'Washington',
           'West Virginia', 'Wisconsin', 'Wyoming'],
          dtype='object')




```python
len(index_census_state)
```




    50




```python
# Now checking the same for the gun data

index_gun_state = df_gun.groupby('state').sum().index
```


```python
index_gun_state
```




    Index(['Alabama', 'Alaska', 'Arizona', 'Arkansas', 'California', 'Colorado',
           'Connecticut', 'Delaware', 'District of Columbia', 'Florida', 'Georgia',
           'Guam', 'Hawaii', 'Idaho', 'Illinois', 'Indiana', 'Iowa', 'Kansas',
           'Kentucky', 'Louisiana', 'Maine', 'Mariana Islands', 'Maryland',
           'Massachusetts', 'Michigan', 'Minnesota', 'Mississippi', 'Missouri',
           'Montana', 'Nebraska', 'Nevada', 'New Hampshire', 'New Jersey',
           'New Mexico', 'New York', 'North Carolina', 'North Dakota', 'Ohio',
           'Oklahoma', 'Oregon', 'Pennsylvania', 'Puerto Rico', 'Rhode Island',
           'South Carolina', 'South Dakota', 'Tennessee', 'Texas', 'Utah',
           'Vermont', 'Virgin Islands', 'Virginia', 'Washington', 'West Virginia',
           'Wisconsin', 'Wyoming'],
          dtype='object', name='state')




```python
len(index_gun_state)
```




    55



**Both data sets do not have the equivalent amount of 'states' listed. Since the code before showed us that there were no duplicates and null values we need to check if some states have not been mentioned.**


```python
for s in index_gun_state:
    if s not in index_census_state:
            print(s)
```

    District of Columbia
    Guam
    Mariana Islands
    Puerto Rico
    Virgin Islands
    

**Now we can see precisely which states are not included in the gun data and furthermore have to be taken into account(excluded) in the future analysis.**

<a id='analysis'></a>
# Exploratory Data Analysis

**1. What is the overall trend of gun purchases?**


```python
# sum the totals by month
totals_sum = df_gun.groupby('month')['totals'].sum()

totals_sum.plot(x= 'totals', y= 'month', title = 'Total Sum of Gun Data', kind ='line')

```




    <matplotlib.axes._subplots.AxesSubplot at 0x14937bfde88>




![png](output_39_1.png)


**By looking at this graph we can clearly see an increase in overall gun sales from the year 1998 to 2007. Although the trend was more or less stable in the period of 1998 and 2003, the growth started to show an increase around year 2005 where closer to 2011 we can see that it hit the highest peak. Later on it was jumping up and down untill 2015 where a new peak has been established higher than the one in 2015.**

**2. How many permit rechecks have their been per month? or **


```python
df_gun.iloc[:, [0,2]]
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>month</th>
      <th>permit</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <td>0</td>
      <td>2017-09</td>
      <td>16717.0</td>
    </tr>
    <tr>
      <td>1</td>
      <td>2017-09</td>
      <td>209.0</td>
    </tr>
    <tr>
      <td>2</td>
      <td>2017-09</td>
      <td>5069.0</td>
    </tr>
    <tr>
      <td>3</td>
      <td>2017-09</td>
      <td>2935.0</td>
    </tr>
    <tr>
      <td>4</td>
      <td>2017-09</td>
      <td>57839.0</td>
    </tr>
    <tr>
      <td>...</td>
      <td>...</td>
      <td>...</td>
    </tr>
    <tr>
      <td>12480</td>
      <td>1998-11</td>
      <td>0.0</td>
    </tr>
    <tr>
      <td>12481</td>
      <td>1998-11</td>
      <td>1.0</td>
    </tr>
    <tr>
      <td>12482</td>
      <td>1998-11</td>
      <td>3.0</td>
    </tr>
    <tr>
      <td>12483</td>
      <td>1998-11</td>
      <td>0.0</td>
    </tr>
    <tr>
      <td>12484</td>
      <td>1998-11</td>
      <td>8.0</td>
    </tr>
  </tbody>
</table>
<p>12485 rows × 2 columns</p>
</div>




```python
total_rechecks = df_gun.groupby('month')['permit_recheck'].sum()
total_rechecks
```




    month
    1998-11        0.0
    1998-12        0.0
    1999-01        0.0
    1999-02        0.0
    1999-03        0.0
                ...   
    2017-05    79404.0
    2017-06    71398.0
    2017-07    71040.0
    2017-08    85237.0
    2017-09    76567.0
    Name: permit_recheck, Length: 227, dtype: float64



**It is impossible to answer this questions because most of the data is not filled, therefore we can not properly answer this question.**

**3. What is the population that falls under the category of age below 18, on April 1st, 2010?** 


```python
df_census.iloc [7, 2:]
```




    Alabama           23.70%
    Alaska            26.40%
    Arizona           25.50%
    Arkansas          24.40%
    California        25.00%
    Colorado          24.40%
    Connecticut       22.90%
    Delaware          22.90%
    Florida           21.30%
    Georgia           25.70%
    Hawaii            22.30%
    Idaho             27.40%
    Illinois          24.40%
    Indiana           24.80%
    Iowa              23.90%
    Kansas            25.50%
    Kentucky          23.60%
    Louisiana         24.70%
    Maine             20.70%
    Maryland          23.40%
    Massachusetts     21.70%
    Michigan          23.70%
    Minnesota         24.20%
    Mississippi       25.50%
    Missouri          23.80%
    Montana           22.60%
    Nebraska          25.10%
    Nevada            24.60%
    New Hampshire     21.80%
    New Jersey        23.50%
    New Mexico         0.252
    New York           0.223
    North Carolina     0.239
    North Dakota       0.223
    Ohio               0.237
    Oklahoma           0.248
    Oregon             0.226
    Pennsylvania        0.22
    Rhode Island       0.213
    South Carolina     0.234
    South Dakota       0.249
    Tennessee          0.236
    Texas             27.30%
    Utah              31.50%
    Vermont           20.70%
    Virginia          23.20%
    Washington        23.50%
    West Virginia     20.90%
    Wisconsin         23.60%
    Wyoming           24.00%
    Name: 7, dtype: object



**By looking at this data we can clearly see that the highest number of population below age 18 goes to Utah with %31.50 and the lowest number is in Rhode Island with the %0.213.**

**4. What was the state with the lowest percentage for Asians Alone?**


```python
df_census.iloc [15, 2:]
```




    Alabama            1.40%
    Alaska             6.30%
    Arizona            3.40%
    Arkansas           1.60%
    California        14.80%
    Colorado           3.30%
    Connecticut        4.70%
    Delaware           4.00%
    Florida            2.90%
    Georgia            4.10%
    Hawaii            37.70%
    Idaho              1.50%
    Illinois           5.50%
    Indiana            2.20%
    Iowa               2.50%
    Kansas             3.00%
    Kentucky           1.50%
    Louisiana          1.80%
    Maine              1.20%
    Maryland           6.60%
    Massachusetts      6.70%
    Michigan           3.10%
    Minnesota          4.90%
    Mississippi        1.10%
    Missouri           2.00%
    Montana            0.80%
    Nebraska           2.50%
    Nevada             8.70%
    New Hampshire      2.70%
    New Jersey         9.80%
    New Mexico         0.017
    New York           0.089
    North Carolina     0.029
    North Dakota       0.015
    Ohio               0.022
    Oklahoma           0.022
    Oregon             0.045
    Pennsylvania       0.035
    Rhode Island       0.036
    South Carolina     0.016
    South Dakota       0.015
    Tennessee          0.018
    Texas              4.80%
    Utah               2.50%
    Vermont            1.80%
    Virginia           6.60%
    Washington         8.60%
    West Virginia      0.80%
    Wisconsin          2.80%
    Wyoming            1.00%
    Name: 15, dtype: object



**By looking at this data we can clearly see that the highest number of population with Asians Alone goes Hawaii with %37.70 and the lowest numbers are in both South and North Dakota with %0.015.**

**5. How many guns were registered in the year 2017, January? What is that number compared to the data 10 years ago?**


```python
gun_jan2017 =df_gun.query('month == "2017-09"')
gun_jan2017
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>month</th>
      <th>state</th>
      <th>permit</th>
      <th>permit_recheck</th>
      <th>handgun</th>
      <th>long_gun</th>
      <th>other</th>
      <th>multiple</th>
      <th>admin</th>
      <th>prepawn_handgun</th>
      <th>...</th>
      <th>returned_other</th>
      <th>rentals_handgun</th>
      <th>rentals_long_gun</th>
      <th>private_sale_handgun</th>
      <th>private_sale_long_gun</th>
      <th>private_sale_other</th>
      <th>return_to_seller_handgun</th>
      <th>return_to_seller_long_gun</th>
      <th>return_to_seller_other</th>
      <th>totals</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <td>0</td>
      <td>2017-09</td>
      <td>Alabama</td>
      <td>16717.0</td>
      <td>0.0</td>
      <td>5734.0</td>
      <td>6320.0</td>
      <td>221.0</td>
      <td>317</td>
      <td>0.0</td>
      <td>15.0</td>
      <td>...</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>9.0</td>
      <td>16.0</td>
      <td>3.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>3.0</td>
      <td>32019</td>
    </tr>
    <tr>
      <td>1</td>
      <td>2017-09</td>
      <td>Alaska</td>
      <td>209.0</td>
      <td>2.0</td>
      <td>2320.0</td>
      <td>2930.0</td>
      <td>219.0</td>
      <td>160</td>
      <td>0.0</td>
      <td>5.0</td>
      <td>...</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>17.0</td>
      <td>24.0</td>
      <td>1.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>6303</td>
    </tr>
    <tr>
      <td>2</td>
      <td>2017-09</td>
      <td>Arizona</td>
      <td>5069.0</td>
      <td>382.0</td>
      <td>11063.0</td>
      <td>7946.0</td>
      <td>920.0</td>
      <td>631</td>
      <td>0.0</td>
      <td>13.0</td>
      <td>...</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>38.0</td>
      <td>12.0</td>
      <td>2.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>28394</td>
    </tr>
    <tr>
      <td>3</td>
      <td>2017-09</td>
      <td>Arkansas</td>
      <td>2935.0</td>
      <td>632.0</td>
      <td>4347.0</td>
      <td>6063.0</td>
      <td>165.0</td>
      <td>366</td>
      <td>51.0</td>
      <td>12.0</td>
      <td>...</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>13.0</td>
      <td>23.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>2.0</td>
      <td>1.0</td>
      <td>17747</td>
    </tr>
    <tr>
      <td>4</td>
      <td>2017-09</td>
      <td>California</td>
      <td>57839.0</td>
      <td>0.0</td>
      <td>37165.0</td>
      <td>24581.0</td>
      <td>2984.0</td>
      <td>0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>...</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>123506</td>
    </tr>
    <tr>
      <td>5</td>
      <td>2017-09</td>
      <td>Colorado</td>
      <td>4356.0</td>
      <td>0.0</td>
      <td>15751.0</td>
      <td>13448.0</td>
      <td>1007.0</td>
      <td>1062</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>...</td>
      <td>1.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>35873</td>
    </tr>
    <tr>
      <td>6</td>
      <td>2017-09</td>
      <td>Connecticut</td>
      <td>4343.0</td>
      <td>673.0</td>
      <td>4834.0</td>
      <td>1993.0</td>
      <td>274.0</td>
      <td>0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>...</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>12117</td>
    </tr>
    <tr>
      <td>7</td>
      <td>2017-09</td>
      <td>Delaware</td>
      <td>275.0</td>
      <td>0.0</td>
      <td>1414.0</td>
      <td>1538.0</td>
      <td>66.0</td>
      <td>68</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>...</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>55.0</td>
      <td>34.0</td>
      <td>3.0</td>
      <td>1.0</td>
      <td>2.0</td>
      <td>0.0</td>
      <td>3502</td>
    </tr>
    <tr>
      <td>8</td>
      <td>2017-09</td>
      <td>District of Columbia</td>
      <td>1.0</td>
      <td>0.0</td>
      <td>56.0</td>
      <td>4.0</td>
      <td>0.0</td>
      <td>0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>...</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>61</td>
    </tr>
    <tr>
      <td>9</td>
      <td>2017-09</td>
      <td>Florida</td>
      <td>10784.0</td>
      <td>0.0</td>
      <td>39199.0</td>
      <td>17949.0</td>
      <td>2319.0</td>
      <td>1721</td>
      <td>1.0</td>
      <td>18.0</td>
      <td>...</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>11.0</td>
      <td>9.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>1.0</td>
      <td>0.0</td>
      <td>77390</td>
    </tr>
    <tr>
      <td>10</td>
      <td>2017-09</td>
      <td>Georgia</td>
      <td>12074.0</td>
      <td>0.0</td>
      <td>10933.0</td>
      <td>7982.0</td>
      <td>315.0</td>
      <td>494</td>
      <td>0.0</td>
      <td>20.0</td>
      <td>...</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>17.0</td>
      <td>7.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>35371</td>
    </tr>
    <tr>
      <td>11</td>
      <td>2017-09</td>
      <td>Guam</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>74.0</td>
      <td>47.0</td>
      <td>10.0</td>
      <td>3</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>...</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>135</td>
    </tr>
    <tr>
      <td>12</td>
      <td>2017-09</td>
      <td>Hawaii</td>
      <td>946.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>...</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>948</td>
    </tr>
    <tr>
      <td>13</td>
      <td>2017-09</td>
      <td>Idaho</td>
      <td>5162.0</td>
      <td>0.0</td>
      <td>3058.0</td>
      <td>5241.0</td>
      <td>187.0</td>
      <td>205</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>...</td>
      <td>1.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>7.0</td>
      <td>14.0</td>
      <td>1.0</td>
      <td>3.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>14938</td>
    </tr>
    <tr>
      <td>14</td>
      <td>2017-09</td>
      <td>Illinois</td>
      <td>15712.0</td>
      <td>71432.0</td>
      <td>18290.0</td>
      <td>10201.0</td>
      <td>0.0</td>
      <td>814</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>...</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>116449</td>
    </tr>
    <tr>
      <td>15</td>
      <td>2017-09</td>
      <td>Indiana</td>
      <td>18241.0</td>
      <td>0.0</td>
      <td>16093.0</td>
      <td>11332.0</td>
      <td>1123.0</td>
      <td>597</td>
      <td>79.0</td>
      <td>5.0</td>
      <td>...</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>75.0</td>
      <td>57.0</td>
      <td>6.0</td>
      <td>4.0</td>
      <td>4.0</td>
      <td>0.0</td>
      <td>48524</td>
    </tr>
    <tr>
      <td>16</td>
      <td>2017-09</td>
      <td>Iowa</td>
      <td>5847.0</td>
      <td>1217.0</td>
      <td>151.0</td>
      <td>2640.0</td>
      <td>27.0</td>
      <td>1</td>
      <td>1.0</td>
      <td>0.0</td>
      <td>...</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>1.0</td>
      <td>7.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>9975</td>
    </tr>
    <tr>
      <td>17</td>
      <td>2017-09</td>
      <td>Kansas</td>
      <td>1567.0</td>
      <td>3.0</td>
      <td>4518.0</td>
      <td>5025.0</td>
      <td>306.0</td>
      <td>297</td>
      <td>0.0</td>
      <td>3.0</td>
      <td>...</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>16.0</td>
      <td>12.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>1.0</td>
      <td>0.0</td>
      <td>12856</td>
    </tr>
    <tr>
      <td>18</td>
      <td>2017-09</td>
      <td>Kentucky</td>
      <td>378384.0</td>
      <td>0.0</td>
      <td>8112.0</td>
      <td>7543.0</td>
      <td>253.0</td>
      <td>543</td>
      <td>1.0</td>
      <td>16.0</td>
      <td>...</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>21.0</td>
      <td>19.0</td>
      <td>1.0</td>
      <td>2.0</td>
      <td>1.0</td>
      <td>0.0</td>
      <td>398706</td>
    </tr>
    <tr>
      <td>19</td>
      <td>2017-09</td>
      <td>Louisiana</td>
      <td>1827.0</td>
      <td>0.0</td>
      <td>10495.0</td>
      <td>11573.0</td>
      <td>635.0</td>
      <td>776</td>
      <td>0.0</td>
      <td>6.0</td>
      <td>...</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>28.0</td>
      <td>43.0</td>
      <td>3.0</td>
      <td>2.0</td>
      <td>2.0</td>
      <td>0.0</td>
      <td>27821</td>
    </tr>
    <tr>
      <td>20</td>
      <td>2017-09</td>
      <td>Maine</td>
      <td>783.0</td>
      <td>0.0</td>
      <td>3026.0</td>
      <td>4220.0</td>
      <td>179.0</td>
      <td>186</td>
      <td>1.0</td>
      <td>0.0</td>
      <td>...</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>11.0</td>
      <td>8.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>1.0</td>
      <td>0.0</td>
      <td>8715</td>
    </tr>
    <tr>
      <td>21</td>
      <td>2017-09</td>
      <td>Mariana Islands</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>12.0</td>
      <td>3.0</td>
      <td>0.0</td>
      <td>1</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>...</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>16</td>
    </tr>
    <tr>
      <td>22</td>
      <td>2017-09</td>
      <td>Maryland</td>
      <td>2424.0</td>
      <td>0.0</td>
      <td>3389.0</td>
      <td>4897.0</td>
      <td>168.0</td>
      <td>34</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>...</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>26.0</td>
      <td>1.0</td>
      <td>0.0</td>
      <td>1.0</td>
      <td>0.0</td>
      <td>11255</td>
    </tr>
    <tr>
      <td>23</td>
      <td>2017-09</td>
      <td>Massachusetts</td>
      <td>7160.0</td>
      <td>0.0</td>
      <td>4749.0</td>
      <td>2808.0</td>
      <td>449.0</td>
      <td>158</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>...</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>55.0</td>
      <td>33.0</td>
      <td>20.0</td>
      <td>4.0</td>
      <td>4.0</td>
      <td>1.0</td>
      <td>15460</td>
    </tr>
    <tr>
      <td>24</td>
      <td>2017-09</td>
      <td>Michigan</td>
      <td>16571.0</td>
      <td>19.0</td>
      <td>8654.0</td>
      <td>10676.0</td>
      <td>379.0</td>
      <td>163</td>
      <td>0.0</td>
      <td>1.0</td>
      <td>...</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>21.0</td>
      <td>40.0</td>
      <td>1.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>36944</td>
    </tr>
    <tr>
      <td>25</td>
      <td>2017-09</td>
      <td>Minnesota</td>
      <td>25645.0</td>
      <td>0.0</td>
      <td>4862.0</td>
      <td>12677.0</td>
      <td>346.0</td>
      <td>273</td>
      <td>0.0</td>
      <td>1.0</td>
      <td>...</td>
      <td>1.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>13.0</td>
      <td>16.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>1.0</td>
      <td>1.0</td>
      <td>44552</td>
    </tr>
    <tr>
      <td>26</td>
      <td>2017-09</td>
      <td>Mississippi</td>
      <td>1362.0</td>
      <td>0.0</td>
      <td>6260.0</td>
      <td>6035.0</td>
      <td>206.0</td>
      <td>405</td>
      <td>0.0</td>
      <td>33.0</td>
      <td>...</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>11.0</td>
      <td>9.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>17491</td>
    </tr>
    <tr>
      <td>27</td>
      <td>2017-09</td>
      <td>Missouri</td>
      <td>791.0</td>
      <td>0.0</td>
      <td>16993.0</td>
      <td>14395.0</td>
      <td>1050.0</td>
      <td>991</td>
      <td>0.0</td>
      <td>12.0</td>
      <td>...</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>75.0</td>
      <td>66.0</td>
      <td>3.0</td>
      <td>1.0</td>
      <td>3.0</td>
      <td>0.0</td>
      <td>37571</td>
    </tr>
    <tr>
      <td>28</td>
      <td>2017-09</td>
      <td>Montana</td>
      <td>1076.0</td>
      <td>0.0</td>
      <td>2395.0</td>
      <td>4878.0</td>
      <td>140.0</td>
      <td>216</td>
      <td>3.0</td>
      <td>4.0</td>
      <td>...</td>
      <td>2.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>10.0</td>
      <td>21.0</td>
      <td>4.0</td>
      <td>2.0</td>
      <td>1.0</td>
      <td>0.0</td>
      <td>10283</td>
    </tr>
    <tr>
      <td>29</td>
      <td>2017-09</td>
      <td>Nebraska</td>
      <td>3036.0</td>
      <td>113.0</td>
      <td>110.0</td>
      <td>1989.0</td>
      <td>11.0</td>
      <td>4</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>...</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>10.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>5345</td>
    </tr>
    <tr>
      <td>30</td>
      <td>2017-09</td>
      <td>Nevada</td>
      <td>1952.0</td>
      <td>0.0</td>
      <td>3992.0</td>
      <td>2509.0</td>
      <td>251.0</td>
      <td>237</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>...</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>9460</td>
    </tr>
    <tr>
      <td>31</td>
      <td>2017-09</td>
      <td>New Hampshire</td>
      <td>2795.0</td>
      <td>0.0</td>
      <td>4410.0</td>
      <td>3248.0</td>
      <td>132.0</td>
      <td>3</td>
      <td>2.0</td>
      <td>0.0</td>
      <td>...</td>
      <td>1.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>4.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>10689</td>
    </tr>
    <tr>
      <td>32</td>
      <td>2017-09</td>
      <td>New Jersey</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>3985.0</td>
      <td>3040.0</td>
      <td>140.0</td>
      <td>0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>...</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>7165</td>
    </tr>
    <tr>
      <td>33</td>
      <td>2017-09</td>
      <td>New Mexico</td>
      <td>847.0</td>
      <td>0.0</td>
      <td>5309.0</td>
      <td>4508.0</td>
      <td>353.0</td>
      <td>284</td>
      <td>0.0</td>
      <td>5.0</td>
      <td>...</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>8.0</td>
      <td>5.0</td>
      <td>1.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>12491</td>
    </tr>
    <tr>
      <td>34</td>
      <td>2017-09</td>
      <td>New York</td>
      <td>2933.0</td>
      <td>1164.0</td>
      <td>8392.0</td>
      <td>16213.0</td>
      <td>998.0</td>
      <td>185</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>...</td>
      <td>1.0</td>
      <td>3.0</td>
      <td>5.0</td>
      <td>348.0</td>
      <td>328.0</td>
      <td>19.0</td>
      <td>7.0</td>
      <td>4.0</td>
      <td>1.0</td>
      <td>30703</td>
    </tr>
    <tr>
      <td>35</td>
      <td>2017-09</td>
      <td>North Carolina</td>
      <td>19292.0</td>
      <td>0.0</td>
      <td>1235.0</td>
      <td>11340.0</td>
      <td>657.0</td>
      <td>233</td>
      <td>0.0</td>
      <td>11.0</td>
      <td>...</td>
      <td>0.0</td>
      <td>12.0</td>
      <td>5.0</td>
      <td>9.0</td>
      <td>40.0</td>
      <td>2.0</td>
      <td>0.0</td>
      <td>1.0</td>
      <td>0.0</td>
      <td>37325</td>
    </tr>
    <tr>
      <td>36</td>
      <td>2017-09</td>
      <td>North Dakota</td>
      <td>486.0</td>
      <td>0.0</td>
      <td>1359.0</td>
      <td>2919.0</td>
      <td>99.0</td>
      <td>82</td>
      <td>3.0</td>
      <td>0.0</td>
      <td>...</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>8.0</td>
      <td>17.0</td>
      <td>2.0</td>
      <td>1.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>5212</td>
    </tr>
    <tr>
      <td>37</td>
      <td>2017-09</td>
      <td>Ohio</td>
      <td>8741.0</td>
      <td>490.0</td>
      <td>21085.0</td>
      <td>14998.0</td>
      <td>1202.0</td>
      <td>1026</td>
      <td>0.0</td>
      <td>9.0</td>
      <td>...</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>58.0</td>
      <td>36.0</td>
      <td>4.0</td>
      <td>1.0</td>
      <td>1.0</td>
      <td>0.0</td>
      <td>49942</td>
    </tr>
    <tr>
      <td>38</td>
      <td>2017-09</td>
      <td>Oklahoma</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>8869.0</td>
      <td>9020.0</td>
      <td>741.0</td>
      <td>807</td>
      <td>0.0</td>
      <td>17.0</td>
      <td>...</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>59.0</td>
      <td>37.0</td>
      <td>4.0</td>
      <td>1.0</td>
      <td>5.0</td>
      <td>0.0</td>
      <td>23371</td>
    </tr>
    <tr>
      <td>39</td>
      <td>2017-09</td>
      <td>Oregon</td>
      <td>3774.0</td>
      <td>11.0</td>
      <td>11557.0</td>
      <td>11773.0</td>
      <td>0.0</td>
      <td>7</td>
      <td>1.0</td>
      <td>0.0</td>
      <td>...</td>
      <td>1.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>27277</td>
    </tr>
    <tr>
      <td>40</td>
      <td>2017-09</td>
      <td>Pennsylvania</td>
      <td>23144.0</td>
      <td>0.0</td>
      <td>39825.0</td>
      <td>13222.0</td>
      <td>48.0</td>
      <td>0</td>
      <td>179.0</td>
      <td>0.0</td>
      <td>...</td>
      <td>1.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>77003</td>
    </tr>
    <tr>
      <td>41</td>
      <td>2017-09</td>
      <td>Puerto Rico</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>619.0</td>
      <td>123.0</td>
      <td>17.0</td>
      <td>22</td>
      <td>0.0</td>
      <td>1.0</td>
      <td>...</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>1.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>791</td>
    </tr>
    <tr>
      <td>42</td>
      <td>2017-09</td>
      <td>Rhode Island</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>907.0</td>
      <td>619.0</td>
      <td>70.0</td>
      <td>163</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>...</td>
      <td>5.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>15.0</td>
      <td>8.0</td>
      <td>1.0</td>
      <td>1.0</td>
      <td>2.0</td>
      <td>0.0</td>
      <td>1799</td>
    </tr>
    <tr>
      <td>43</td>
      <td>2017-09</td>
      <td>South Carolina</td>
      <td>9380.0</td>
      <td>349.0</td>
      <td>7574.0</td>
      <td>6037.0</td>
      <td>379.0</td>
      <td>295</td>
      <td>0.0</td>
      <td>22.0</td>
      <td>...</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>13.0</td>
      <td>10.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>25930</td>
    </tr>
    <tr>
      <td>44</td>
      <td>2017-09</td>
      <td>South Dakota</td>
      <td>562.0</td>
      <td>0.0</td>
      <td>2020.0</td>
      <td>4155.0</td>
      <td>154.0</td>
      <td>141</td>
      <td>0.0</td>
      <td>1.0</td>
      <td>...</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>3.0</td>
      <td>14.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>7457</td>
    </tr>
    <tr>
      <td>45</td>
      <td>2017-09</td>
      <td>Tennessee</td>
      <td>16887.0</td>
      <td>0.0</td>
      <td>19219.0</td>
      <td>13746.0</td>
      <td>1042.0</td>
      <td>0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>...</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>50945</td>
    </tr>
    <tr>
      <td>46</td>
      <td>2017-09</td>
      <td>Texas</td>
      <td>31390.0</td>
      <td>0.0</td>
      <td>39119.0</td>
      <td>39416.0</td>
      <td>2768.0</td>
      <td>2473</td>
      <td>0.0</td>
      <td>59.0</td>
      <td>...</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>121.0</td>
      <td>87.0</td>
      <td>13.0</td>
      <td>2.0</td>
      <td>5.0</td>
      <td>0.0</td>
      <td>128260</td>
    </tr>
    <tr>
      <td>47</td>
      <td>2017-09</td>
      <td>Utah</td>
      <td>12094.0</td>
      <td>25.0</td>
      <td>2840.0</td>
      <td>3960.0</td>
      <td>212.0</td>
      <td>0</td>
      <td>0.0</td>
      <td>3.0</td>
      <td>...</td>
      <td>16.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>20041</td>
    </tr>
    <tr>
      <td>48</td>
      <td>2017-09</td>
      <td>Vermont</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>1276.0</td>
      <td>1591.0</td>
      <td>90.0</td>
      <td>80</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>...</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>3.0</td>
      <td>6.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>3084</td>
    </tr>
    <tr>
      <td>49</td>
      <td>2017-09</td>
      <td>Virgin Islands</td>
      <td>1.0</td>
      <td>0.0</td>
      <td>6.0</td>
      <td>2.0</td>
      <td>0.0</td>
      <td>0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>...</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>9</td>
    </tr>
    <tr>
      <td>50</td>
      <td>2017-09</td>
      <td>Virginia</td>
      <td>585.0</td>
      <td>0.0</td>
      <td>19676.0</td>
      <td>15075.0</td>
      <td>1100.0</td>
      <td>0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>...</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>36446</td>
    </tr>
    <tr>
      <td>51</td>
      <td>2017-09</td>
      <td>Washington</td>
      <td>11451.0</td>
      <td>44.0</td>
      <td>13292.0</td>
      <td>11548.0</td>
      <td>1623.0</td>
      <td>587</td>
      <td>3.0</td>
      <td>12.0</td>
      <td>...</td>
      <td>9.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>701.0</td>
      <td>590.0</td>
      <td>42.0</td>
      <td>5.0</td>
      <td>13.0</td>
      <td>1.0</td>
      <td>43049</td>
    </tr>
    <tr>
      <td>52</td>
      <td>2017-09</td>
      <td>West Virginia</td>
      <td>1668.0</td>
      <td>0.0</td>
      <td>5204.0</td>
      <td>6161.0</td>
      <td>216.0</td>
      <td>387</td>
      <td>11.0</td>
      <td>15.0</td>
      <td>...</td>
      <td>3.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>16.0</td>
      <td>18.0</td>
      <td>0.0</td>
      <td>1.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>16723</td>
    </tr>
    <tr>
      <td>53</td>
      <td>2017-09</td>
      <td>Wisconsin</td>
      <td>12224.0</td>
      <td>0.0</td>
      <td>10918.0</td>
      <td>13133.0</td>
      <td>612.0</td>
      <td>43</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>...</td>
      <td>3.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>20.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>37506</td>
    </tr>
    <tr>
      <td>54</td>
      <td>2017-09</td>
      <td>Wyoming</td>
      <td>280.0</td>
      <td>11.0</td>
      <td>1337.0</td>
      <td>2015.0</td>
      <td>61.0</td>
      <td>97</td>
      <td>1.0</td>
      <td>1.0</td>
      <td>...</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>10.0</td>
      <td>14.0</td>
      <td>1.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>4281</td>
    </tr>
  </tbody>
</table>
<p>55 rows × 27 columns</p>
</div>




```python
gun_jan2017.groupby(['month'])['totals'].sum()
```




    month
    2017-09    1857226
    Name: totals, dtype: int64




```python
gun_jan2007 = df_gun.query('month == "2007-12"')
gun_jan2007
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>month</th>
      <th>state</th>
      <th>permit</th>
      <th>permit_recheck</th>
      <th>handgun</th>
      <th>long_gun</th>
      <th>other</th>
      <th>multiple</th>
      <th>admin</th>
      <th>prepawn_handgun</th>
      <th>...</th>
      <th>returned_other</th>
      <th>rentals_handgun</th>
      <th>rentals_long_gun</th>
      <th>private_sale_handgun</th>
      <th>private_sale_long_gun</th>
      <th>private_sale_other</th>
      <th>return_to_seller_handgun</th>
      <th>return_to_seller_long_gun</th>
      <th>return_to_seller_other</th>
      <th>totals</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <td>6435</td>
      <td>2007-12</td>
      <td>Alabama</td>
      <td>0.0</td>
      <td>NaN</td>
      <td>10877.0</td>
      <td>23192.0</td>
      <td>NaN</td>
      <td>461</td>
      <td>0.0</td>
      <td>18.0</td>
      <td>...</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>37499</td>
    </tr>
    <tr>
      <td>6436</td>
      <td>2007-12</td>
      <td>Alaska</td>
      <td>0.0</td>
      <td>NaN</td>
      <td>2227.0</td>
      <td>3234.0</td>
      <td>NaN</td>
      <td>98</td>
      <td>0.0</td>
      <td>5.0</td>
      <td>...</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>5754</td>
    </tr>
    <tr>
      <td>6437</td>
      <td>2007-12</td>
      <td>Arizona</td>
      <td>1888.0</td>
      <td>NaN</td>
      <td>7678.0</td>
      <td>9370.0</td>
      <td>NaN</td>
      <td>331</td>
      <td>0.0</td>
      <td>9.0</td>
      <td>...</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>20191</td>
    </tr>
    <tr>
      <td>6438</td>
      <td>2007-12</td>
      <td>Arkansas</td>
      <td>2555.0</td>
      <td>NaN</td>
      <td>4741.0</td>
      <td>13939.0</td>
      <td>NaN</td>
      <td>247</td>
      <td>7.0</td>
      <td>4.0</td>
      <td>...</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>23434</td>
    </tr>
    <tr>
      <td>6439</td>
      <td>2007-12</td>
      <td>California</td>
      <td>23638.0</td>
      <td>NaN</td>
      <td>18279.0</td>
      <td>20378.0</td>
      <td>NaN</td>
      <td>0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>...</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>62295</td>
    </tr>
    <tr>
      <td>6440</td>
      <td>2007-12</td>
      <td>Colorado</td>
      <td>1.0</td>
      <td>NaN</td>
      <td>9359.0</td>
      <td>14562.0</td>
      <td>NaN</td>
      <td>1921</td>
      <td>3.0</td>
      <td>0.0</td>
      <td>...</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>25846</td>
    </tr>
    <tr>
      <td>6441</td>
      <td>2007-12</td>
      <td>Connecticut</td>
      <td>4398.0</td>
      <td>NaN</td>
      <td>3077.0</td>
      <td>3558.0</td>
      <td>NaN</td>
      <td>75</td>
      <td>379.0</td>
      <td>0.0</td>
      <td>...</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>11487</td>
    </tr>
    <tr>
      <td>6442</td>
      <td>2007-12</td>
      <td>Delaware</td>
      <td>0.0</td>
      <td>NaN</td>
      <td>597.0</td>
      <td>1508.0</td>
      <td>NaN</td>
      <td>27</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>...</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>2132</td>
    </tr>
    <tr>
      <td>6443</td>
      <td>2007-12</td>
      <td>District of Columbia</td>
      <td>0.0</td>
      <td>NaN</td>
      <td>1.0</td>
      <td>0.0</td>
      <td>NaN</td>
      <td>0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>...</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>1</td>
    </tr>
    <tr>
      <td>6444</td>
      <td>2007-12</td>
      <td>Florida</td>
      <td>0.0</td>
      <td>NaN</td>
      <td>23703.0</td>
      <td>24625.0</td>
      <td>NaN</td>
      <td>917</td>
      <td>4.0</td>
      <td>9.0</td>
      <td>...</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>50129</td>
    </tr>
    <tr>
      <td>6445</td>
      <td>2007-12</td>
      <td>Georgia</td>
      <td>4850.0</td>
      <td>NaN</td>
      <td>10296.0</td>
      <td>21868.0</td>
      <td>NaN</td>
      <td>455</td>
      <td>0.0</td>
      <td>17.0</td>
      <td>...</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>39603</td>
    </tr>
    <tr>
      <td>6446</td>
      <td>2007-12</td>
      <td>Guam</td>
      <td>0.0</td>
      <td>NaN</td>
      <td>10.0</td>
      <td>26.0</td>
      <td>NaN</td>
      <td>0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>...</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>36</td>
    </tr>
    <tr>
      <td>6447</td>
      <td>2007-12</td>
      <td>Hawaii</td>
      <td>544.0</td>
      <td>NaN</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>NaN</td>
      <td>0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>...</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>544</td>
    </tr>
    <tr>
      <td>6448</td>
      <td>2007-12</td>
      <td>Idaho</td>
      <td>1120.0</td>
      <td>NaN</td>
      <td>2364.0</td>
      <td>6581.0</td>
      <td>NaN</td>
      <td>124</td>
      <td>1.0</td>
      <td>2.0</td>
      <td>...</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>10864</td>
    </tr>
    <tr>
      <td>6449</td>
      <td>2007-12</td>
      <td>Illinois</td>
      <td>27329.0</td>
      <td>NaN</td>
      <td>6639.0</td>
      <td>12126.0</td>
      <td>NaN</td>
      <td>423</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>...</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>46517</td>
    </tr>
    <tr>
      <td>6450</td>
      <td>2007-12</td>
      <td>Indiana</td>
      <td>0.0</td>
      <td>NaN</td>
      <td>7943.0</td>
      <td>14213.0</td>
      <td>NaN</td>
      <td>341</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>...</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>22840</td>
    </tr>
    <tr>
      <td>6451</td>
      <td>2007-12</td>
      <td>Iowa</td>
      <td>6234.0</td>
      <td>NaN</td>
      <td>23.0</td>
      <td>6371.0</td>
      <td>NaN</td>
      <td>3</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>...</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>12722</td>
    </tr>
    <tr>
      <td>6452</td>
      <td>2007-12</td>
      <td>Kansas</td>
      <td>0.0</td>
      <td>NaN</td>
      <td>3946.0</td>
      <td>8716.0</td>
      <td>NaN</td>
      <td>241</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>...</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>13468</td>
    </tr>
    <tr>
      <td>6453</td>
      <td>2007-12</td>
      <td>Kentucky</td>
      <td>121387.0</td>
      <td>NaN</td>
      <td>9547.0</td>
      <td>17620.0</td>
      <td>NaN</td>
      <td>567</td>
      <td>0.0</td>
      <td>8.0</td>
      <td>...</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>151630</td>
    </tr>
    <tr>
      <td>6454</td>
      <td>2007-12</td>
      <td>Louisiana</td>
      <td>0.0</td>
      <td>NaN</td>
      <td>8474.0</td>
      <td>22360.0</td>
      <td>NaN</td>
      <td>344</td>
      <td>0.0</td>
      <td>1.0</td>
      <td>...</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>32690</td>
    </tr>
    <tr>
      <td>6455</td>
      <td>2007-12</td>
      <td>Maine</td>
      <td>0.0</td>
      <td>NaN</td>
      <td>1172.0</td>
      <td>3138.0</td>
      <td>NaN</td>
      <td>68</td>
      <td>0.0</td>
      <td>9.0</td>
      <td>...</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>4512</td>
    </tr>
    <tr>
      <td>6456</td>
      <td>2007-12</td>
      <td>Mariana Islands</td>
      <td>0.0</td>
      <td>NaN</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>NaN</td>
      <td>0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>...</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>0</td>
    </tr>
    <tr>
      <td>6457</td>
      <td>2007-12</td>
      <td>Maryland</td>
      <td>610.0</td>
      <td>NaN</td>
      <td>2093.0</td>
      <td>5974.0</td>
      <td>NaN</td>
      <td>4</td>
      <td>0.0</td>
      <td>1.0</td>
      <td>...</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>8798</td>
    </tr>
    <tr>
      <td>6458</td>
      <td>2007-12</td>
      <td>Massachusetts</td>
      <td>6209.0</td>
      <td>NaN</td>
      <td>1970.0</td>
      <td>1687.0</td>
      <td>NaN</td>
      <td>56</td>
      <td>1.0</td>
      <td>0.0</td>
      <td>...</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>9923</td>
    </tr>
    <tr>
      <td>6459</td>
      <td>2007-12</td>
      <td>Michigan</td>
      <td>11328.0</td>
      <td>NaN</td>
      <td>2327.0</td>
      <td>17095.0</td>
      <td>NaN</td>
      <td>78</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>...</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>31038</td>
    </tr>
    <tr>
      <td>6460</td>
      <td>2007-12</td>
      <td>Minnesota</td>
      <td>5252.0</td>
      <td>NaN</td>
      <td>4258.0</td>
      <td>11430.0</td>
      <td>NaN</td>
      <td>151</td>
      <td>0.0</td>
      <td>1.0</td>
      <td>...</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>21456</td>
    </tr>
    <tr>
      <td>6461</td>
      <td>2007-12</td>
      <td>Mississippi</td>
      <td>593.0</td>
      <td>NaN</td>
      <td>5073.0</td>
      <td>19981.0</td>
      <td>NaN</td>
      <td>273</td>
      <td>0.0</td>
      <td>33.0</td>
      <td>...</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>28149</td>
    </tr>
    <tr>
      <td>6462</td>
      <td>2007-12</td>
      <td>Missouri</td>
      <td>377.0</td>
      <td>NaN</td>
      <td>11779.0</td>
      <td>19402.0</td>
      <td>NaN</td>
      <td>438</td>
      <td>0.0</td>
      <td>4.0</td>
      <td>...</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>33205</td>
    </tr>
    <tr>
      <td>6463</td>
      <td>2007-12</td>
      <td>Montana</td>
      <td>333.0</td>
      <td>NaN</td>
      <td>2108.0</td>
      <td>5903.0</td>
      <td>NaN</td>
      <td>134</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>...</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>9367</td>
    </tr>
    <tr>
      <td>6464</td>
      <td>2007-12</td>
      <td>Nebraska</td>
      <td>2132.0</td>
      <td>NaN</td>
      <td>1.0</td>
      <td>4774.0</td>
      <td>NaN</td>
      <td>1</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>...</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>6994</td>
    </tr>
    <tr>
      <td>6465</td>
      <td>2007-12</td>
      <td>Nevada</td>
      <td>659.0</td>
      <td>NaN</td>
      <td>3255.0</td>
      <td>3832.0</td>
      <td>NaN</td>
      <td>166</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>...</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>8214</td>
    </tr>
    <tr>
      <td>6466</td>
      <td>2007-12</td>
      <td>New Hampshire</td>
      <td>1107.0</td>
      <td>NaN</td>
      <td>1650.0</td>
      <td>2415.0</td>
      <td>NaN</td>
      <td>6</td>
      <td>8.0</td>
      <td>0.0</td>
      <td>...</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>5189</td>
    </tr>
    <tr>
      <td>6467</td>
      <td>2007-12</td>
      <td>New Jersey</td>
      <td>0.0</td>
      <td>NaN</td>
      <td>1270.0</td>
      <td>2355.0</td>
      <td>NaN</td>
      <td>37</td>
      <td>2.0</td>
      <td>0.0</td>
      <td>...</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>3664</td>
    </tr>
    <tr>
      <td>6468</td>
      <td>2007-12</td>
      <td>New Mexico</td>
      <td>217.0</td>
      <td>NaN</td>
      <td>3509.0</td>
      <td>5988.0</td>
      <td>NaN</td>
      <td>250</td>
      <td>0.0</td>
      <td>2.0</td>
      <td>...</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>10804</td>
    </tr>
    <tr>
      <td>6469</td>
      <td>2007-12</td>
      <td>New York</td>
      <td>3066.0</td>
      <td>NaN</td>
      <td>3263.0</td>
      <td>14674.0</td>
      <td>NaN</td>
      <td>56</td>
      <td>7.0</td>
      <td>0.0</td>
      <td>...</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>21071</td>
    </tr>
    <tr>
      <td>6470</td>
      <td>2007-12</td>
      <td>North Carolina</td>
      <td>9735.0</td>
      <td>NaN</td>
      <td>265.0</td>
      <td>24934.0</td>
      <td>NaN</td>
      <td>109</td>
      <td>0.0</td>
      <td>16.0</td>
      <td>...</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>37789</td>
    </tr>
    <tr>
      <td>6471</td>
      <td>2007-12</td>
      <td>North Dakota</td>
      <td>170.0</td>
      <td>NaN</td>
      <td>656.0</td>
      <td>3125.0</td>
      <td>NaN</td>
      <td>24</td>
      <td>2.0</td>
      <td>0.0</td>
      <td>...</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>4089</td>
    </tr>
    <tr>
      <td>6472</td>
      <td>2007-12</td>
      <td>Ohio</td>
      <td>0.0</td>
      <td>NaN</td>
      <td>13589.0</td>
      <td>22970.0</td>
      <td>NaN</td>
      <td>625</td>
      <td>0.0</td>
      <td>15.0</td>
      <td>...</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>38508</td>
    </tr>
    <tr>
      <td>6473</td>
      <td>2007-12</td>
      <td>Oklahoma</td>
      <td>0.0</td>
      <td>NaN</td>
      <td>6978.0</td>
      <td>13444.0</td>
      <td>NaN</td>
      <td>467</td>
      <td>0.0</td>
      <td>13.0</td>
      <td>...</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>23047</td>
    </tr>
    <tr>
      <td>6474</td>
      <td>2007-12</td>
      <td>Oregon</td>
      <td>62.0</td>
      <td>NaN</td>
      <td>6502.0</td>
      <td>13106.0</td>
      <td>NaN</td>
      <td>323</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>...</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>19993</td>
    </tr>
    <tr>
      <td>6475</td>
      <td>2007-12</td>
      <td>Pennsylvania</td>
      <td>177.0</td>
      <td>NaN</td>
      <td>0.0</td>
      <td>53300.0</td>
      <td>NaN</td>
      <td>118</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>...</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>53595</td>
    </tr>
    <tr>
      <td>6476</td>
      <td>2007-12</td>
      <td>Puerto Rico</td>
      <td>0.0</td>
      <td>NaN</td>
      <td>593.0</td>
      <td>103.0</td>
      <td>NaN</td>
      <td>23</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>...</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>719</td>
    </tr>
    <tr>
      <td>6477</td>
      <td>2007-12</td>
      <td>Rhode Island</td>
      <td>0.0</td>
      <td>NaN</td>
      <td>358.0</td>
      <td>490.0</td>
      <td>NaN</td>
      <td>99</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>...</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>947</td>
    </tr>
    <tr>
      <td>6478</td>
      <td>2007-12</td>
      <td>South Carolina</td>
      <td>1688.0</td>
      <td>NaN</td>
      <td>6008.0</td>
      <td>11940.0</td>
      <td>NaN</td>
      <td>204</td>
      <td>0.0</td>
      <td>7.0</td>
      <td>...</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>20889</td>
    </tr>
    <tr>
      <td>6479</td>
      <td>2007-12</td>
      <td>South Dakota</td>
      <td>0.0</td>
      <td>NaN</td>
      <td>1088.0</td>
      <td>4696.0</td>
      <td>NaN</td>
      <td>80</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>...</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>6087</td>
    </tr>
    <tr>
      <td>6480</td>
      <td>2007-12</td>
      <td>Tennessee</td>
      <td>0.0</td>
      <td>NaN</td>
      <td>13549.0</td>
      <td>21021.0</td>
      <td>NaN</td>
      <td>556</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>...</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>35126</td>
    </tr>
    <tr>
      <td>6481</td>
      <td>2007-12</td>
      <td>Texas</td>
      <td>0.0</td>
      <td>NaN</td>
      <td>30442.0</td>
      <td>58440.0</td>
      <td>NaN</td>
      <td>1549</td>
      <td>4998.0</td>
      <td>36.0</td>
      <td>...</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>102476</td>
    </tr>
    <tr>
      <td>6482</td>
      <td>2007-12</td>
      <td>Utah</td>
      <td>2971.0</td>
      <td>NaN</td>
      <td>3542.0</td>
      <td>9392.0</td>
      <td>NaN</td>
      <td>139</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>...</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>16044</td>
    </tr>
    <tr>
      <td>6483</td>
      <td>2007-12</td>
      <td>Vermont</td>
      <td>0.0</td>
      <td>NaN</td>
      <td>513.0</td>
      <td>1257.0</td>
      <td>NaN</td>
      <td>11</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>...</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>1781</td>
    </tr>
    <tr>
      <td>6484</td>
      <td>2007-12</td>
      <td>Virgin Islands</td>
      <td>12.0</td>
      <td>NaN</td>
      <td>29.0</td>
      <td>3.0</td>
      <td>NaN</td>
      <td>1</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>...</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>45</td>
    </tr>
    <tr>
      <td>6485</td>
      <td>2007-12</td>
      <td>Virginia</td>
      <td>0.0</td>
      <td>NaN</td>
      <td>11571.0</td>
      <td>18884.0</td>
      <td>NaN</td>
      <td>349</td>
      <td>2.0</td>
      <td>0.0</td>
      <td>...</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>30806</td>
    </tr>
    <tr>
      <td>6486</td>
      <td>2007-12</td>
      <td>Washington</td>
      <td>6145.0</td>
      <td>NaN</td>
      <td>7995.0</td>
      <td>12543.0</td>
      <td>NaN</td>
      <td>309</td>
      <td>7.0</td>
      <td>4.0</td>
      <td>...</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>28224</td>
    </tr>
    <tr>
      <td>6487</td>
      <td>2007-12</td>
      <td>West Virginia</td>
      <td>0.0</td>
      <td>NaN</td>
      <td>4051.0</td>
      <td>9789.0</td>
      <td>NaN</td>
      <td>224</td>
      <td>0.0</td>
      <td>2.0</td>
      <td>...</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>15750</td>
    </tr>
    <tr>
      <td>6488</td>
      <td>2007-12</td>
      <td>Wisconsin</td>
      <td>0.0</td>
      <td>NaN</td>
      <td>4178.0</td>
      <td>12216.0</td>
      <td>NaN</td>
      <td>0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>...</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>16506</td>
    </tr>
    <tr>
      <td>6489</td>
      <td>2007-12</td>
      <td>Wyoming</td>
      <td>226.0</td>
      <td>NaN</td>
      <td>1284.0</td>
      <td>3314.0</td>
      <td>NaN</td>
      <td>56</td>
      <td>3.0</td>
      <td>1.0</td>
      <td>...</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>5123</td>
    </tr>
  </tbody>
</table>
<p>55 rows × 27 columns</p>
</div>




```python
gun_jan2007.groupby(['month'])['totals'].sum()
```




    month
    2007-12    1229610
    Name: totals, dtype: int64



**We can see that even though 2017 didnt have last three months inside the data, it still shows a greater number compared to 2007, which indicates that overall the gun sales have been steadily growing**

**6. What is the most popular gun sale in the whole data?**


```python
gun_type = {}
column_state = df_gun.columns[2:25]

for c in column_state:
    gun_type[c] = df_gun[c].sum()
    
max(gun_type, key=gun_type.get)
```




    'long_gun'



**This shows that 'long_gun' is the most popular gun among others**

<a id='conclusion'></a>
# Conclusion

        **Overall, we could perfectly run both datas and see the numbers that were corresponding for each data type. The gun data has been ongoing since 1998, however the problem was that most of the latest data had 0 for some of the categories. Therefore, the speculations can not be made since there is a possibility that those numbers were not properly written. If we drop the null value it will repove that specific row and therefore effect the data. However, if we are precise with our commands we can answer our questions.
        Regarding the census, it shows different population categories. It was useful to run some commands in order to test yourself how to 'play' with different rows and columns. The only negative aspect, is that it is hard to link census data to gun data. Primarily because the data is so different, and most likely census is missing that gun correlation for the proper similarities and differences to be constructed.**
